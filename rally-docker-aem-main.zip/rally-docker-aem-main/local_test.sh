#! /bin/bash
# if you modify this script, please run shellcheck against it
# brew install shellcheck

set -ue

function printHelp()
{
  echo ""
  echo -e "Usage $(basename "${0}")"
  echo -e "==============="
  echo -e "\t -l run hado[l]int - Suggestions for Docker file best practices - https://github.com/hadolint/hadolint"
  echo -e "\t -g run [g]oss tests - Verify image is running as expected - https://github.com/aelsabbahy/goss"
  echo -e "\t -d run dive analysis - Gives hints at ways to make docker images smaller - https://github.com/wagoodman/dive"
  echo ""
  echo -e "\t -a run [a]ll the tests this script is capable of"
  echo -e "\t -f run only [f]ast tests, hadolint and goss"
  echo ""
  echo -e "Adding to this script"
  echo -e "==============="
  echo -e "\t if you modify this script, please run shellcheck against it"
  echo -e "\t shellcheck $(basename "${0}")"
  echo -e "\t -s run only shellcheck on this script, yes its a script that checks itself, what could go wrong."
  echo -e "\t\t Not part of the -a flag.  Running this does not run any other test."
  exit 1
}

function errorOut()
{
  echo "==========ERROR==========="
  echo "$1"
  echo "==========ERROR==========="
  exit 1
}

function printHeader()
{
  echo "--------- $1 ---------"
}

function checkHadolint()
{
  printHeader "Running HadoLint"

  # run the same lint as github does, catch error before pushing
  if ! which hadolint 1>/dev/null 2>/dev/null ; then
    errorOut "please install hadolint for linting - 'brew install hadolint'"
  fi

  if ! hadolint Dockerfile; then
    errorOut "hadolint detected an issue, please see message above, exiting out.  Run 'hadolint Dockerfile' to run test by hand."
  fi
}

function checkGoss()
{
  printHeader "Performing Goss Check"
  docker run --rm --entrypoint='/workspace/goss' -v "$PWD":/workspace rally-docker-image -g workspace/spec/goss.yaml validate --format=rspecish
}

function checkShellCheck()
{
  printHeader "Performing Shell Check"
  if ! which shellcheck 1>/dev/null 2>/dev/null ; then
    errorOut "please install shellcheck for good shell linting - 'brew install shellcheck'"
  fi
  shellcheck "${0}"
}

function buildDocker()
{
  printHeader "Building Docker Image"
  docker build -t rally-docker-image .
}

function cleanUp()
{
  printHeader "Cleaning up..."
  docker rmi rally-docker-image
}

function checkDive()
{
  printHeader "Running Dive"

  # run the same dive as github does, catch error before pushing
  if ! which dive 1>/dev/null 2>/dev/null ; then
    errorOut "please install dive for docker size testing - 'brew install dive'"
  fi

  if ! CI=true dive rally-docker-image; then
    errorOut "dive detected an issue, please see message above, exiting out."
  fi
}




# if no flags passed, go straight to printHelp
if [ $# -eq 0 ]; then
  printHelp
fi

# defaults
RUN_HADOLINT=false
RUN_DIVE=false
RUN_GOSS=false
RUN_SHELLCHECK=false

# this script should be called and not wrapped, but if it ever is, reset the getops loop count
# https://eklitzke.org/using-local-optind-with-bash-getopts
OPTIND=1

while getopts ":hxldgafs" opt; do
  case ${opt} in
    h )
      printHelp
      ;;
    l )
      RUN_HADOLINT=true
      ;;
    g )
      RUN_GOSS=true
      ;;
    d )
      RUN_DIVE=true
      ;;
    s )
      RUN_SHELLCHECK=true
      ;;
    # run all tests
    a )
      RUN_DIVE=true
      RUN_GOSS=true
      RUN_HADOLINT=true
      ;;
    # run fast tests
    f )
      RUN_GOSS=true
      RUN_HADOLINT=true
      ;;
    x )
      set -x
      ;;
    \? )
      echo "Unknown flag sent: ${OPTARG}"
      printHelp
      ;;
    : ) # If expected argument for a flag is omitted
      echo "Error: -${OPTARG} requires an argument."
      printHelp
      ;;
    * ) # not sure how this can ever even be hit
        # https://www.unix.com/shell-programming-and-scripting/150847-getopt-invalid-option-selection.html
      echo "Unknown issue with passed arguments"
      printHelp
      ;;
  esac
done

# $@ will have any extra things left over
# https://unix.stackexchange.com/questions/214141/explain-the-shell-command-shift-optind-1/214151
# ./myscript -z foo
# echo "before getops---> $@" #  gives '-z foo'
shift "$((OPTIND-1))"
# echo "after getops and shift ---> $@" # only shows 'foo'

if [ $RUN_SHELLCHECK == true ]; then
  checkShellCheck
fi

if [ $RUN_HADOLINT == true ]; then
  checkHadolint
fi

buildDocker

if [ $RUN_GOSS == true ]; then
  checkGoss
fi

if [ $RUN_DIVE == true ]; then
  checkDive
fi

cleanUp
