_Looking for images created from this template?_

- github: https://github.com/search?q=topic%3Adocker-image+org%3AAudaxHealthInc+fork%3Atrue
- artifactory: https://artifacts.werally.in/artifactory/webapp/#/artifacts/browse/tree/General/docker-dev/rally-docker

# rally-docker-image-template

This is a templated repo that gives the structure to create a docker images
repo with a structure.

To see a full demonstration of the features of this docker image pipeline, we
have prepared a [Youtube playlist](
https://www.youtube.com/playlist?list=PLTeqofW2bm1U0jByrYRDBr5w7wzMA1Y0p)
walking through how to get started.  You will need to be logged in with your
rallyhealth.com email address.

If you don't have 45 minutes to spare or prefer prose documentation, that's ok,
just keep reading:

To use this repository:

1. Select "Use This Template" [here](https://github.com/AudaxHealthInc/rally-docker-image-template).

1. Give it a descriptive name, and then after creating the repository, add a
   Topic of `docker-image` via "About" settings.

1. Upate repoman.yaml with your team and JIRA project.

1. Update your Dockerfile as appropriate.

1. Update your `.github/workflows/ci-docker.yaml` as appropriate.  Update `DOCKER_IMAGE_NAME`.
   *Important* Make sure the `FROM`
   line of your base docker image matches `upstreamImagePath`.  This will set
   things up to rebuild your image whenever there is an upstream update.

1. Update `spec/goss.yaml` as appropriate to set up some tests to verify you're
   creating the image you want.

That's it!

## Naming Conventions

For a dependency `foo`, we clone the template as a new Github repo `rally-docker-foo`.

The image is tagged at the path `docker.werally.in/rally-docker/rally-foo`.

## Making a release

All commits to `master` will automatically update the `latest` tag for this
image.

To release a tagged docker image, create and push a git tag with the docker
image tag you want.

All tags and `latest` will automatically rebuild if the configured
`upstreamImagePath` image is updated.

## Writing Tests

Writing goss tests for Docker images can be strange and unfamiliar.  As a rule of thumb, we should include tests to verify any new files, packages or commands we add to an image.

This only scratches the surface of goss functionality.  See [all available tests](https://github.com/aelsabbahy/goss/blob/master/docs/manual.md#available-tests)

Tests are written in `spec/goss.yaml`.  They will be run automatically in GitHub.  To test them locally, see section below.

### Packages

We can test that a package was installed via a Linux package manager (`apk`, `apt-get`, etc.)

```goss
package:
  myPackage:
    installed: true

```

### Files

We can test for the existence of a file, and verify if contains a string `foo` (typically used for a verison number):

```goss
file:
  /myPath/myFile:
    exists: true
    contains: ['vX.Y.Z']

```

### Commands

We can test that a command is available within the container by verifying executing it and verifying its exit status and stdout:

```goss
command:
  mycommand:
    exec: 'myCommand --version'
    exit-status: 0
    stdout:
     - vX.Y.Z

```

## Local Testing

Run `local_test.sh` to build, test and clean up your image locally.  It will be tagged as `rally-docker-image` through the duration of the test.

   ```sh
   # from repo root
   ./local_test.sh

   ```

You can manually test your image with these steps:

1. Building your image locally (requires Docker)

   ```sh
   # from repo root
   docker build -t <MY_LOCAL_IMAGE_TAG> .

   ```

2. Running that image as a container with goss mounted as a volume

   ```sh
   docker run --rm --entrypoint='/workspace/goss' -v $PWD:/workspace <MY_LOCAL_IMAGE_TAG> -g workspace/spec/goss.yaml validate --format=rspecish

   ```

3. Clean up your test image

   ```sh
   docker rmi <MY_LOCAL_IMAGE_TAG>

   ```
