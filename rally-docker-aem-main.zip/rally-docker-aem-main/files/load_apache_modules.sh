#!/bin/bash

modules="deflate headers proxy proxy_balancer proxy_http rewrite slotmem_shm ssl xml2enc"

for i in $modules; do
  echo $i;
  a2enmod $i
done
