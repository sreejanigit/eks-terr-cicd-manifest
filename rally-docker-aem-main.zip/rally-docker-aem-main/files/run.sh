#!/bin/bash

# Required Variables
if [[ -z "${AEM_ADMIN_PASSWORD}" ]]; then
    echo "Missing Environment Variable: AEM_ADMIN_PASSWORD";
    exit 2;
fi
if [[ -z "${CQ_PORT}" ]]; then
    echo "Missing Environment Variable: CQ_PORT";
    exit 2;
fi
if [[ -z "${CQ_RUNMODE}" ]]; then
    echo "Missing Environment Variable: CQ_RUNMODE";
    exit 2;
fi
if [[ -z "${CQ_VERBOSE}" ]]; then
    echo "Missing Environment Variable: CQ_VERBOSE";
    exit 2;
fi
if [[ -z "${CQ_JVM_OPTS}" ]]; then
    echo "Missing Environment Variable: CQ_JVM_OPTS";
    exit 2;
fi
if [[ -z "${HOST}" ]]; then
    echo "Missing Environment Variable: HOST";
    exit 2;
fi
if [[ "${CQ_VERBOSE}" == "true" ]]; then
    set -x
fi

# This script manages AEM processes and ensure correct operational mode
AEM_RUNTIME_DIR="/opt/aem"

mode=$(echo "${CQ_RUNMODE}" |tr ',' ' ' |tr ' ' '\n' | grep -E '(author|publish)')
echo $mode

mkdir -p "${AEM_RUNTIME_DIR}/${mode}"
cp -r ${AEM_RUNTIME_DIR}/archive/* ${AEM_RUNTIME_DIR}/${mode}/
jar_file=$(ls -1 ${AEM_RUNTIME_DIR}/${mode}/*.jar |head -1)
cd "${AEM_RUNTIME_DIR}/${mode}" && java -jar "${jar_file}" -unpack;

# Start Apache
apachectl start &
echo "Apache Status: $?"

sleep 60

echo "${AEM_ADMIN_PASSWORD}" > /opt/aem/${mode}/passwordfile.properties
# Start the AEM service
CQ_PORT=${CQ_PORT} CQ_RUNMODE=${CQ_RUNMODE} CQ_VERBOSE=${CQ_VERBOSE} CQ_JVM_OPTS="${CQ_JVM_OPTS} ${CQ_JVM_MEM_OPTS} -Dadmin.password.file=/opt/aem/${mode}/passwordfile.properties" ${AEM_RUNTIME_DIR}/${mode}/crx-quickstart/bin/start &

sleep 60

# Configure LDAP packages
curl -s -u "admin:${AEM_ADMIN_PASSWORD}" -F file=@"/opt/aem/archive/aem-ad-ldap-authentication-1.0.0.zip" -F name="aem-ad-ldap-authentication-1.0.0" -F force=true -F install=true "http://${HOST}:${CQ_PORT}/crx/packmgr/service.jsp" 1>/dev/null
echo "Status: $?"

# Configure Status Check package
curl -s -u "admin:${AEM_ADMIN_PASSWORD}" -F file=@"/opt/aem/archive/aem-status-check-1.2.3.zip" -F name="aem-status-check-1.2.3" -F force=true -F install=true "http://${HOST}:${CQ_PORT}/crx/packmgr/service.jsp" 1>/dev/null
echo "Status: $?"

# Create a deployment user for aem deployments
curl -s -u "admin:${AEM_ADMIN_PASSWORD}" -FcreateUser=aem-deployer -FauthorizableId=aem-deployer -Frep:password=Deployer@aem -Fprofile/familyName=aem-deployer "http://${HOST}:${CQ_PORT}/libs/granite/security/post/authorizables" 1>/dev/null
echo "Status: $?"

# Add aem-deployer to administrators
curl -s -u "admin:${AEM_ADMIN_PASSWORD}" -FaddMembers=aem-deployer "http://${HOST}:${CQ_PORT}/home/groups/a/administrators.rw.html" 1>/dev/null
echo "Status: $?"


# fix the wait
while true; do
  ps aux;
  #cat ${AEM_RUNTIME_DIR}/${mode}/crx-quickstart/logs/error.log | grep  -v '*INFO*';
  #cat ${AEM_RUNTIME_DIR}/${mode}/crx-quickstart/logs/stdout.log;
  sleep 20;
done
