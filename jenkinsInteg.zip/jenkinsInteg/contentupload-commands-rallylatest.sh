#!/bin/bash
Deployment=$( curl -u admin:Myuhc@dmin -F cmd=upload -F force=true -F package=@MNR-DAM-Individual-pdfs.zip https://author.better-alien.rally-dev.com/crx/packmgr/service/.json; curl -u admin:Myuhc@dmin -F cmd=install https://author.better-alien.rally-dev.com/crx/packmgr/service/.json/etc/packages/my_packages/MNR-DAM-Individual-pdfs.zip)
echo "$Deployment"
if echo "${DEPLOYMENT}" | grep -q "${INSTALL_SUCCESS_STATUS}"; then
    echo "[MNR] - Package installed successfully"
fi